 
 const hero = document.querySelector('.nav-button');
 const line1 = document.querySelector('.line-1');


 const tl = new TimelineMax();

 t1.fromTo(line1,{height:0%},{height:'80%'})